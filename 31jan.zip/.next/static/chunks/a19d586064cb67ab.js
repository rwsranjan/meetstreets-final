__turbopack_load_page_chunks__("/login", [
  "static/chunks/23335036841b91d7.js",
  "static/chunks/21bacc4485f02580.js",
  "static/chunks/0daf0721ddf2780f.js",
  "static/chunks/4b5fc69e4d8e0b1e.js",
  "static/chunks/turbopack-091cea15223b97b9.js"
])
