__turbopack_load_page_chunks__("/_app", [
  "static/chunks/21bacc4485f02580.js",
  "static/chunks/5b27140b586229a5.js",
  "static/chunks/4b5fc69e4d8e0b1e.js",
  "static/chunks/0daf0721ddf2780f.js",
  "static/chunks/7363c17a20bcddb1.css",
  "static/chunks/turbopack-c4ab4acc5ee933f7.js"
])
