__turbopack_load_page_chunks__("/profile/[userId]", [
  "static/chunks/755f62401edf1190.js",
  "static/chunks/89eb18b6af5a93f9.js",
  "static/chunks/4b5fc69e4d8e0b1e.js",
  "static/chunks/0daf0721ddf2780f.js",
  "static/chunks/21bacc4485f02580.js",
  "static/chunks/turbopack-3e61beb83d64e1ca.js"
])
