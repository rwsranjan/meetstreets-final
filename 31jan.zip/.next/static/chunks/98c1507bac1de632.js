__turbopack_load_page_chunks__("/_error", [
  "static/chunks/500bcdde76ac2942.js",
  "static/chunks/21bacc4485f02580.js",
  "static/chunks/4b5fc69e4d8e0b1e.js",
  "static/chunks/0daf0721ddf2780f.js",
  "static/chunks/turbopack-a7e15675be9ce252.js"
])
