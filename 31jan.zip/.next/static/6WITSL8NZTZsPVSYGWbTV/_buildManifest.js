self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/293c7d7833283088.js"
  ],
  "/_error": [
    "static/chunks/98c1507bac1de632.js"
  ],
  "/complete-profile": [
    "static/chunks/c002aa72976cb797.js"
  ],
  "/dashboard": [
    "static/chunks/c70797816a9aa601.js"
  ],
  "/explore": [
    "static/chunks/397ac46527bd8fa8.js"
  ],
  "/login": [
    "static/chunks/a19d586064cb67ab.js"
  ],
  "/profile/[userId]": [
    "static/chunks/ac5f862a19818761.js"
  ],
  "/register": [
    "static/chunks/bd275ae618fe5c45.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/auth/login",
    "/api/auth/register",
    "/api/coins/deposit",
    "/api/coins/withdraw",
    "/api/match/request",
    "/api/match/respond",
    "/api/meeting/complete",
    "/api/meeting/create",
    "/api/profile",
    "/api/profile/update",
    "/api/search/profile",
    "/api/social-login",
    "/complete-profile",
    "/dashboard",
    "/explore",
    "/login",
    "/profile/[userId]",
    "/register"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()