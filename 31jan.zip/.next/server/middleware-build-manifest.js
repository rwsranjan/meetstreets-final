globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/61c476d30661bc81.js",
      "static/chunks/turbopack-59331b5d07f229fa.js"
    ],
    "/_app": [
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/5b27140b586229a5.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/7363c17a20bcddb1.css",
      "static/chunks/turbopack-c4ab4acc5ee933f7.js"
    ],
    "/_error": [
      "static/chunks/500bcdde76ac2942.js",
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/turbopack-a7e15675be9ce252.js"
    ],
    "/complete-profile": [
      "static/chunks/89eb18b6af5a93f9.js",
      "static/chunks/c75fdb6b49b56fa0.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/turbopack-fecf551d6b2cd0e7.js"
    ],
    "/dashboard": [
      "static/chunks/89eb18b6af5a93f9.js",
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/9d00354336ac3ee4.js",
      "static/chunks/turbopack-562be5b8b1b5e924.js"
    ],
    "/explore": [
      "static/chunks/89eb18b6af5a93f9.js",
      "static/chunks/8374d6795371c1db.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/turbopack-979b9a991819ac70.js"
    ],
    "/login": [
      "static/chunks/23335036841b91d7.js",
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/turbopack-091cea15223b97b9.js"
    ],
    "/profile/[userId]": [
      "static/chunks/755f62401edf1190.js",
      "static/chunks/89eb18b6af5a93f9.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/turbopack-3e61beb83d64e1ca.js"
    ],
    "/register": [
      "static/chunks/a36e068640cfc2a7.js",
      "static/chunks/21bacc4485f02580.js",
      "static/chunks/4b5fc69e4d8e0b1e.js",
      "static/chunks/0daf0721ddf2780f.js",
      "static/chunks/turbopack-babd1b2fa7bc1994.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];