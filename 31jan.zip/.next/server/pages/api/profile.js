var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/profile.js")
R.c("server/chunks/[root-of-the-server]__929cee7b._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(44257)
module.exports=R.m(44257).exports
