var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/coins/deposit.js")
R.c("server/chunks/[root-of-the-server]__0cc7e4b6._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(99140)
module.exports=R.m(99140).exports
