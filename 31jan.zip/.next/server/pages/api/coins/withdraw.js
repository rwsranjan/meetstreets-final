var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/coins/withdraw.js")
R.c("server/chunks/[root-of-the-server]__329ab81a._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(49530)
module.exports=R.m(49530).exports
