var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/profile/update.js")
R.c("server/chunks/[root-of-the-server]__211b003d._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(63864)
module.exports=R.m(63864).exports
