var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/match/request.js")
R.c("server/chunks/[root-of-the-server]__3d392be5._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(3451)
module.exports=R.m(3451).exports
