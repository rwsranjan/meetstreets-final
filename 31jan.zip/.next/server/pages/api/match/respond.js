var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/match/respond.js")
R.c("server/chunks/[root-of-the-server]__9e38d7c7._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(14241)
module.exports=R.m(14241).exports
