var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/social-login.js")
R.c("server/chunks/[root-of-the-server]__2a4b6a2b._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(31197)
module.exports=R.m(31197).exports
