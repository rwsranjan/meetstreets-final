var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/login.js")
R.c("server/chunks/[root-of-the-server]__03817e92._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(9582)
module.exports=R.m(9582).exports
