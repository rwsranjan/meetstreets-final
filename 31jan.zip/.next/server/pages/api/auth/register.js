var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register.js")
R.c("server/chunks/[root-of-the-server]__2c025fd9._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(67258)
module.exports=R.m(67258).exports
