var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/search/profile.js")
R.c("server/chunks/[root-of-the-server]__939c810f._.js")
R.c("server/chunks/[root-of-the-server]__cc7bb134._.js")
R.m(9632)
module.exports=R.m(9632).exports
