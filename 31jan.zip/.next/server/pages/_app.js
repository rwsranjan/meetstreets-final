var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__b211d920._.js")
R.c("server/chunks/ssr/_eb9ca732._.js")
R.m(76695)
module.exports=R.m(76695).exports
