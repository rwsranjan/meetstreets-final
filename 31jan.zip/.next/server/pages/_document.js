var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[externals]_next_dist_compiled_@opentelemetry_api_2f2eda7e._.js")
R.c("server/chunks/ssr/[root-of-the-server]__b9d85db6._.js")
R.c("server/chunks/ssr/[root-of-the-server]__7a085623._.js")
R.m(67684)
module.exports=R.m(67684).exports
