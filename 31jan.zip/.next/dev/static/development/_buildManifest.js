self.__BUILD_MANIFEST = {
  "/complete-profile": [
    "static/chunks/pages/complete-profile.js"
  ],
  "/login": [
    "static/chunks/pages/login.js"
  ],
  "/register": [
    "static/chunks/pages/register.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/auth/login",
    "/api/auth/register",
    "/api/coins/deposit",
    "/api/coins/withdraw",
    "/api/match/request",
    "/api/match/respond",
    "/api/meeting/complete",
    "/api/meeting/create",
    "/api/profile",
    "/api/profile/update",
    "/api/search/profile",
    "/api/social-login",
    "/complete-profile",
    "/dashboard",
    "/explore",
    "/login",
    "/profile/[userid]",
    "/register"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()