(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_4501ac73._.js",
  "static/chunks/node_modules_next_dist_shared_lib_d64426db._.js",
  "static/chunks/node_modules_next_dist_client_8dd97e7a._.js",
  "static/chunks/node_modules_next_dist_75b597d7._.js",
  "static/chunks/node_modules_next_933cec8d._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_7d3d3e62._.js",
  "static/chunks/[root-of-the-server]__bc67f64a._.js"
],
    source: "entry"
});
