(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_15080aa3._.js",
  "static/chunks/node_modules_next_dist_client_881bc7f7._.js",
  "static/chunks/node_modules_next_dist_75b597d7._.js",
  "static/chunks/node_modules_next_link_207af988.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_9415566b._.js",
  "static/chunks/[root-of-the-server]__78b4c84c._.js",
  "static/chunks/src_styles_globals_5bb75e7e.css"
],
    source: "entry"
});
