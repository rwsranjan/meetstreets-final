(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2d6ba68f._.js",
  "static/chunks/node_modules_next_dist_client_290d85fa._.js",
  "static/chunks/node_modules_next_dist_d989ed6c._.js",
  "static/chunks/node_modules_next_3074c998._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_cb557178._.js",
  "static/chunks/[root-of-the-server]__410c43b9._.js"
],
    source: "entry"
});
