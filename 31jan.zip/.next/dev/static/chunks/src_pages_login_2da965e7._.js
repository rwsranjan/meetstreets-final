(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_1e3a4f5d._.js",
  "static/chunks/node_modules_next_dist_client_881bc7f7._.js",
  "static/chunks/node_modules_next_dist_75b597d7._.js",
  "static/chunks/node_modules_next_6ae0c6e3._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_f1be3ba2._.js",
  "static/chunks/[root-of-the-server]__37a44925._.js"
],
    source: "entry"
});
