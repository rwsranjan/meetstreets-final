__turbopack_load_page_chunks__("/dashboard", [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_2d6ba68f._.js",
  "static/chunks/node_modules_next_dist_client_290d85fa._.js",
  "static/chunks/node_modules_next_dist_d989ed6c._.js",
  "static/chunks/node_modules_next_3074c998._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_db8721a7._.js",
  "static/chunks/[root-of-the-server]__04a48648._.js",
  "static/chunks/src_pages_dashboard_index_2da965e7.js",
  "static/chunks/turbopack-src_pages_dashboard_index_0aba23f1.js"
])
