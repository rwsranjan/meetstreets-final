(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__06b6abd0._.js",
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_f34d46b1._.js",
  "static/chunks/node_modules_next_dist_client_49292203._.js",
  "static/chunks/node_modules_next_dist_d989ed6c._.js",
  "static/chunks/node_modules_next_0ee04be1._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_5f15c6c4._.js"
],
    source: "entry"
});
