var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/node_modules_c47607aa._.js")
R.c("server/chunks/ssr/[root-of-the-server]__833fe8b6._.js")
R.m("[project]/src/pages/_app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/src/pages/_app.js [ssr] (ecmascript)").exports
