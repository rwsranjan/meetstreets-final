var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/login.js")
R.c("server/chunks/ssr/node_modules_next_fb2e875f._.js")
R.c("server/chunks/ssr/[root-of-the-server]__bac999e5._.js")
R.c("server/chunks/ssr/node_modules_186c80ea._.js")
R.c("server/chunks/ssr/[root-of-the-server]__aa0b05e3._.js")
R.c("server/chunks/ssr/node_modules_dea389e4._.js")
R.c("server/chunks/ssr/src_25e17481._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/src/pages/login.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/src/pages/_document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/src/pages/_app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/src/pages/login.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/src/pages/_document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/src/pages/_app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
