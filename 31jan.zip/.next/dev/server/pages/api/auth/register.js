var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/register.js")
R.c("server/chunks/[root-of-the-server]__09b35c2d._.js")
R.c("server/chunks/[root-of-the-server]__b4f7b4ba._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/auth/register.js [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/auth/register.js [api] (ecmascript)\" } [api] (ecmascript)").exports
