var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/login.js")
R.c("server/chunks/[root-of-the-server]__c767f960._.js")
R.c("server/chunks/[root-of-the-server]__fbcab1fd._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/auth/login.js [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/auth/login.js [api] (ecmascript)\" } [api] (ecmascript)").exports
