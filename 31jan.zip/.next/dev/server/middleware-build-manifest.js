globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
      "static/chunks/node_modules_next_dist_shared_lib_15080aa3._.js",
      "static/chunks/node_modules_next_dist_client_881bc7f7._.js",
      "static/chunks/node_modules_next_dist_75b597d7._.js",
      "static/chunks/node_modules_next_link_207af988.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_9415566b._.js",
      "static/chunks/[root-of-the-server]__78b4c84c._.js",
      "static/chunks/src_styles_globals_5bb75e7e.css",
      "static/chunks/src_pages__app_2da965e7._.js",
      "static/chunks/turbopack-src_pages__app_91c84ced._.js"
    ],
    "/complete-profile": [
      "static/chunks/[root-of-the-server]__06b6abd0._.js",
      "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
      "static/chunks/node_modules_next_dist_shared_lib_f34d46b1._.js",
      "static/chunks/node_modules_next_dist_client_49292203._.js",
      "static/chunks/node_modules_next_dist_d989ed6c._.js",
      "static/chunks/node_modules_next_0ee04be1._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_5f15c6c4._.js",
      "static/chunks/src_pages_complete-profile_index_jsx_2da965e7._.js",
      "static/chunks/turbopack-src_pages_complete-profile_index_jsx_4f036675._.js"
    ],
    "/login": [
      "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
      "static/chunks/node_modules_next_dist_shared_lib_1e3a4f5d._.js",
      "static/chunks/node_modules_next_dist_client_881bc7f7._.js",
      "static/chunks/node_modules_next_dist_75b597d7._.js",
      "static/chunks/node_modules_next_6ae0c6e3._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_f1be3ba2._.js",
      "static/chunks/[root-of-the-server]__37a44925._.js",
      "static/chunks/src_pages_login_2da965e7._.js",
      "static/chunks/turbopack-src_pages_login_b762f3db._.js"
    ],
    "/register": [
      "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
      "static/chunks/node_modules_next_dist_shared_lib_1e3a4f5d._.js",
      "static/chunks/node_modules_next_dist_client_881bc7f7._.js",
      "static/chunks/node_modules_next_dist_75b597d7._.js",
      "static/chunks/node_modules_next_6ae0c6e3._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_f1be3ba2._.js",
      "static/chunks/[root-of-the-server]__d8395116._.js",
      "static/chunks/src_pages_register_2da965e7._.js",
      "static/chunks/turbopack-src_pages_register_d3bee30b._.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];