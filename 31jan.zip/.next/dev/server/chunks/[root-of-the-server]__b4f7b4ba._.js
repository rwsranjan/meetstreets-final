module.exports = [
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/lib/mongodb.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$mongoose$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs, [project]/node_modules/mongoose)");
;
const MONGODB_URI = process.env.MONGODB_URI;
if (!MONGODB_URI) {
    throw new Error('Please define the MONGODB_URI environment variable inside .env.local');
}
let cached = /*TURBOPACK member replacement*/ __turbopack_context__.g.mongoose;
if (!cached) {
    cached = /*TURBOPACK member replacement*/ __turbopack_context__.g.mongoose = {
        conn: null,
        promise: null
    };
}
async function dbConnect() {
    if (cached.conn) {
        return cached.conn;
    }
    if (!cached.promise) {
        const opts = {
            bufferCommands: false
        };
        cached.promise = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$mongoose$29$__["default"].connect(MONGODB_URI, opts).then((mongoose)=>{
            return mongoose;
        });
    }
    try {
        cached.conn = await cached.promise;
    } catch (e) {
        cached.promise = null;
        throw e;
    }
    return cached.conn;
}
const __TURBOPACK__default__export__ = dbConnect;
}),
"[project]/models/User.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$mongoose$29$__ = __turbopack_context__.i("[externals]/mongoose [external] (mongoose, cjs, [project]/node_modules/mongoose)");
;
const userSchema = new __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$mongoose$29$__["default"].Schema({
    // =====================
    // Authentication
    // =====================
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    mobile: {
        type: String,
        unique: true,
        sparse: true
    },
    password: {
        type: String,
        required: function() {
            return !this.googleId && !this.facebookId;
        }
    },
    googleId: {
        type: String,
        sparse: true
    },
    facebookId: {
        type: String,
        sparse: true
    },
    // =====================
    // Profile
    // =====================
    profileName: {
        type: String,
        required: true,
        trim: true
    },
    age: {
        type: Number,
        required: true,
        min: 18
    },
    showAge: {
        type: Boolean,
        default: true
    },
    gender: {
        type: String,
        enum: [
            "male",
            "female",
            "non-binary",
            "prefer-not-to-say",
            "other"
        ],
        required: true
    },
    // =====================
    // Address & Location
    // =====================
    address: {
        street: String,
        city: String,
        locality: String,
        state: String,
        country: String,
        pincode: String,
        coordinates: {
            type: {
                type: String,
                enum: [
                    "Point"
                ]
            },
            coordinates: {
                type: [
                    Number
                ] // [lng, lat]
            }
        }
    },
    // =====================
    // Appearance
    // =====================
    height: String,
    ethnicBackground: String,
    // =====================
    // Education & Career
    // =====================
    education: {
        type: String,
        enum: [
            "high-school",
            "bachelors",
            "masters",
            "phd",
            "other"
        ]
    },
    degreeType: String,
    // =====================
    // Dating Preferences
    // =====================
    lookingFor: {
        type: String,
        enum: [
            "long-term",
            "casual",
            "not-sure",
            "marriage",
            "friendship",
            "travel-companion"
        ]
    },
    wantKids: {
        type: String,
        enum: [
            "yes",
            "no",
            "maybe",
            "have-kids"
        ]
    },
    // =====================
    // Lifestyle
    // =====================
    religiousBeliefs: String,
    exerciseHabits: {
        type: String,
        enum: [
            "daily",
            "weekly",
            "occasionally",
            "never"
        ]
    },
    eatingHabits: {
        type: String,
        enum: [
            "vegetarian",
            "vegan",
            "non-vegetarian",
            "pescatarian",
            "other"
        ]
    },
    // =====================
    // Interests
    // =====================
    hobbies: [
        String
    ],
    politicalViews: String,
    favoriteFood: [
        String
    ],
    favoriteMusic: [
        String
    ],
    favoriteMovies: [
        String
    ],
    favoriteTVShows: [
        String
    ],
    favoriteBooks: [
        String
    ],
    // =====================
    // Media
    // =====================
    profilePictures: [
        {
            url: String,
            isPrimary: Boolean,
            uploadedAt: Date
        }
    ],
    profileVideo: {
        url: String,
        uploadedAt: Date
    },
    // =====================
    // App Settings
    // =====================
    ageRange: {
        type: String,
        enum: [
            "18-25",
            "26-30",
            "31-40",
            "40-50",
            "50+"
        ],
        required: true
    },
    interestsMeta: {
        favoritePlaceToMeet: String,
        travelerType: {
            type: String,
            enum: [
                "business",
                "leisure",
                "spiritual",
                "adventure",
                "cultural"
            ]
        }
    },
    purposeOnApp: {
        type: String,
        enum: [
            "offering-time-company",
            "looking-for-time-company",
            "both"
        ],
        required: true
    },
    // =====================
    // Verification
    // =====================
    isKYCVerified: {
        type: Boolean,
        default: false
    },
    // =====================
    // Subscription
    // =====================
    subscriptionType: {
        type: String,
        enum: [
            "free",
            "regular",
            "premium"
        ],
        default: "free"
    },
    subscriptionExpiry: Date,
    // =====================
    // Rewards & Referrals
    // =====================
    coins: {
        type: Number,
        default: 0
    },
    welcomePoints: {
        type: Number,
        default: 100
    },
    referralCode: {
        type: String,
        unique: true,
        sparse: true
    },
    referredBy: {
        type: __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$mongoose$29$__["default"].Schema.Types.ObjectId,
        ref: "User"
    },
    totalReferrals: {
        type: Number,
        default: 0
    },
    // =====================
    // Activity & Status
    // =====================
    isActive: {
        type: Boolean,
        default: true
    },
    isOnline: {
        type: Boolean,
        default: false
    },
    lastSeen: Date,
    // =====================
    // Admin
    // =====================
    isBanned: {
        type: Boolean,
        default: false
    },
    banReason: String
}, {
    timestamps: true
});
// =====================
// Indexes (SAFE & CLEAN)
// =====================
userSchema.index({
    "address.coordinates": "2dsphere"
}, {
    partialFilterExpression: {
        "address.coordinates.coordinates": {
            $type: "array"
        }
    }
});
userSchema.index({
    subscriptionType: 1
});
userSchema.index({
    "address.city": 1,
    "address.locality": 1
});
// =====================
// Referral Code Generator
// =====================
userSchema.pre("save", function(next) {
    if (!this.referralCode) {
        this.referralCode = generateReferralCode();
    }
    next();
});
function generateReferralCode() {
    return "MS" + Math.random().toString(36).substring(2, 10).toUpperCase();
}
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$mongoose$29$__["default"].models.User || __TURBOPACK__imported__module__$5b$externals$5d2f$mongoose__$5b$external$5d$__$28$mongoose$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$mongoose$29$__["default"].model("User", userSchema);
}),
"[project]/src/pages/api/auth/register.js [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mongodb$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/mongodb.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$User$2e$js__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/models/User.js [api] (ecmascript)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$2c$__$5b$project$5d2f$node_modules$2f$bcryptjs$29$__ = __turbopack_context__.i("[externals]/bcryptjs [external] (bcryptjs, esm_import, [project]/node_modules/bcryptjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$jsonwebtoken__$5b$external$5d$__$28$jsonwebtoken$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$jsonwebtoken$29$__ = __turbopack_context__.i("[externals]/jsonwebtoken [external] (jsonwebtoken, cjs, [project]/node_modules/jsonwebtoken)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$2c$__$5b$project$5d2f$node_modules$2f$bcryptjs$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$2c$__$5b$project$5d2f$node_modules$2f$bcryptjs$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
;
;
async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({
            message: 'Method not allowed'
        });
    }
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$mongodb$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"])();
        const { email, mobile, password, profileName, age, gender, purposeOnApp, referralCode, address// optional address from frontend
         } = req.body;
        // ----------------------------
        // Basic Validation
        // ----------------------------
        if (!email || !password || !profileName || !age || !gender || !purposeOnApp) {
            return res.status(400).json({
                message: 'Missing required fields'
            });
        }
        if (age < 18) {
            return res.status(400).json({
                message: 'Must be 18 or older'
            });
        }
        // ----------------------------
        // Check if user exists
        // ----------------------------
        const existingUser = await __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$User$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].findOne({
            $or: [
                {
                    email
                },
                {
                    mobile: mobile || null
                }
            ]
        });
        if (existingUser) {
            return res.status(400).json({
                message: 'User already exists'
            });
        }
        // ----------------------------
        // Calculate age range
        // ----------------------------
        const ageRange = age >= 18 && age <= 25 ? '18-25' : age >= 26 && age <= 30 ? '26-30' : age >= 31 && age <= 40 ? '31-40' : age >= 41 && age <= 50 ? '40-50' : '50+';
        // ----------------------------
        // Handle referral
        // ----------------------------
        let referredBy = null;
        if (referralCode) {
            const referrer = await __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$User$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].findOne({
                referralCode
            });
            if (referrer) {
                referredBy = referrer._id;
                referrer.coins += 50;
                referrer.totalReferrals += 1;
                await referrer.save();
            }
        }
        // ----------------------------
        // Hash password
        // ----------------------------
        const hashedPassword = await __TURBOPACK__imported__module__$5b$externals$5d2f$bcryptjs__$5b$external$5d$__$28$bcryptjs$2c$__esm_import$2c$__$5b$project$5d2f$node_modules$2f$bcryptjs$29$__["default"].hash(password, 10);
        // ----------------------------
        // Clean address coordinates
        // ----------------------------
        let cleanAddress = undefined;
        if (address) {
            cleanAddress = {
                ...address
            };
            if (cleanAddress.coordinates && (!Array.isArray(cleanAddress.coordinates.coordinates) || cleanAddress.coordinates.coordinates.length !== 2)) {
                // Remove invalid coordinates to prevent MongoDB 2dsphere error
                delete cleanAddress.coordinates;
            }
        }
        // ----------------------------
        // Create user
        // ----------------------------
        const user = await __TURBOPACK__imported__module__$5b$project$5d2f$models$2f$User$2e$js__$5b$api$5d$__$28$ecmascript$29$__["default"].create({
            email,
            mobile,
            password: hashedPassword,
            profileName,
            age,
            gender,
            purposeOnApp,
            ageRange,
            referredBy,
            welcomePoints: 100,
            coins: referredBy ? 150 : 100,
            address: cleanAddress // optional
        });
        // ----------------------------
        // Generate JWT
        // ----------------------------
        const token = __TURBOPACK__imported__module__$5b$externals$5d2f$jsonwebtoken__$5b$external$5d$__$28$jsonwebtoken$2c$__cjs$2c$__$5b$project$5d2f$node_modules$2f$jsonwebtoken$29$__["default"].sign({
            userId: user._id,
            email: user.email
        }, process.env.JWT_SECRET, {
            expiresIn: '7d'
        });
        res.status(201).json({
            message: 'User registered successfully',
            token,
            user: {
                id: user._id,
                email: user.email,
                profileName: user.profileName,
                referralCode: user.referralCode,
                coins: user.coins
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            message: 'Server error',
            error: error.message
        });
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b4f7b4ba._.js.map